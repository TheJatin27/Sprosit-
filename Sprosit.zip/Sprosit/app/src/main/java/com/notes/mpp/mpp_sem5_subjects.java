package com.notes.mpp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class mpp_sem5_subjects extends AppCompatActivity {

    private Button SE;
    private Button PHP;
    private Button Python;
    private Button CAH;
    private Button IT;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mpp_sem5_subjects);


        //Software Engineering

        SE=findViewById(R.id.button63);
        SE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://www.youtube.com");
            }
        });

        //Web Development using PHP

        PHP=findViewById(R.id.button64);
        PHP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("xyz");
            }
        });

        //Computer Programming using Python

        Python=findViewById(R.id.button65);
        Python.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("xyz");
            }
        });



        //Computer Architecture and Hardware Maintenance

        CAH=findViewById(R.id.button66);
        CAH.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("xyz");
            }
        });


        //Internet of Things

        IT=findViewById(R.id.button67);
        IT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("xyz");
            }
        });

    }

    private void gotoUrl(String s) {

        Uri uri= Uri.parse(s);
        startActivity(new Intent(Intent.ACTION_VIEW,uri));
    }
}
