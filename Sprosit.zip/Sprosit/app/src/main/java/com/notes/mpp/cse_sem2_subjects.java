package com.notes.mpp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class cse_sem2_subjects extends AppCompatActivity {

    private Button maths2;
    private Button Phy2;
    private Button BEEE;
    private Button MM;
    private Button c;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_cse_sem2_subjects);

        //Applied Maths II

        maths2=findViewById(R.id.button46);
        maths2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("");
            }
        });

        //Physics

        Phy2=findViewById(R.id.button47);
        Phy2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("xyz");
            }
        });

        //Applied Maths II

        BEEE=findViewById(R.id.button48);
        BEEE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("xyz");
            }
        });



        //Multi Media And Animation

        MM=findViewById(R.id.button49);
        MM.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("xyz");
            }
        });


        //C

        c=findViewById(R.id.button50);
        c.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://drive.google.com/drive/u/3/folders/1uQYCvLHFIMBBKk3ZWAPpwdzMLlrp-pyX");
            }
        });


    }

    private void gotoUrl(String s) {

        Uri uri= Uri.parse(s);
        startActivity(new Intent(Intent.ACTION_VIEW,uri));
    }
}