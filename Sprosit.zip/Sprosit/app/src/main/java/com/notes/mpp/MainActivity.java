    package com.notes.mpp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.ads.interstitial.InterstitialAd;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;

    public class MainActivity extends AppCompatActivity {
//    private Button cse;
//    private Button mpp;
//    private Button mc;
//    private Button ce;
//    private Button ee1;
//    private Button ee2;
//    private AdView mAdView;
//    private InterstitialAd mInterstitialAd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//        <-----------------------------------------------Add---------------------------------------------------------------->
MobileAds.initialize(this, new OnInitializationCompleteListener() {
    @Override
    public void onInitializationComplete(@NonNull InitializationStatus initializationStatus) {

    }
});

//mAdView=findViewById(R.id.adView);
//AdRequest adRequest=new AdRequest.Builder().build();
//mAdView.loadAd(adRequest);

//         <-----------------------------------------------Add---------------------------------------------------------------->
//
//        //CSE
//        cse=findViewById(R.id.button);
//        cse.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent intent=new Intent(MainActivity.this,Computer_Science_And_Engineering.class);
//                startActivity(intent);
//            }
//        });
//
//        //MPP
//        mpp=findViewById(R.id.button2);
//        mpp.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent intent=new Intent(MainActivity.this,Mechanical_Production.class);
//                startActivity(intent);
//            }
//        });
//
//        //MC
//
//        mc=findViewById(R.id.button3);
//        mc.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent intent=new Intent(MainActivity.this,Mechanical_CAD.class);
//                startActivity(intent);
//            }
//        });
//
//        //CE
//
//        ce=findViewById(R.id.button4);
//        ce.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent intent=new Intent(MainActivity.this,Civil_Enggering.class);
//                startActivity(intent);
//            }
//        });
//
//        //EE1
//
//        ee1=findViewById(R.id.button5);
//        ee1.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent intent=new Intent(MainActivity.this,Electrical_Enggering.class);
//                startActivity(intent);
//            }
//        });
//
//        //EE2
//
//        ee2=findViewById(R.id.button6);
//        ee2.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent intent=new Intent(MainActivity.this,Electronic_Engineering.class);
//                startActivity(intent);
//            }
//        });

//        <--------------------------------------adds---------------------------------------------------------------->
//        AdRequest adRequest = new AdRequest.Builder().build();
//
//        InterstitialAd.load(this,"ca-app-pub-3940256099942544/1033173712", adRequest,
//                new InterstitialAdLoadCallback() {
//                    @Override
//                    public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
//                        // The mInterstitialAd reference will be null until
//                        // an ad is loaded.
//                        mInterstitialAd = interstitialAd;
//                        Log.i(TAG, "onAdLoaded");
//                    }
//
//                    @Override
//                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
//                        // Handle the error
//                        Log.d(TAG, loadAdError.toString());
//                        mInterstitialAd = null;
//                    }
//                });

//<----------------------------------------------adds------------------------------------------------------------------->
    }
}