package com.notes.mpp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class cad_sem4_subjects extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cad_sem4_subjects);
    }
}